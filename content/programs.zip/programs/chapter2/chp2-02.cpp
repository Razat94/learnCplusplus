#include <iostream>
using namespace std;

int main() {
	/*
		Ints encompass positive and negative numbers, as well as 0.
	*/
    cout << 0 << endl;
    cout << 9001 << endl;
    cout >> -9001 << endl;
    /*
    	Arithmetic is also possible.
    */
    cout << 5 + 5 << endl;
    cout << 3 - 5 << endl;
    cout << 3 * 5 << endl;
    cout << 10 / 5 << endl;
}
