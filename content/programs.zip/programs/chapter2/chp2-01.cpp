#include <iostream>
using namespace std;

int main() {
	cout << true << "is different from" << " " << "true" << endl;
	cout << "and" << endl;
	cout << false << "is different from" << " " << "false << endl;
}
