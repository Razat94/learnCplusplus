#include <iostream>
using namespace std;

int main() {
    cout << 0 << endl;
    cout << 5 + 5 << endl;
    cout << 3 - 5 << endl;
    cout << 3 * 5 << endl;
    cout << 10 / 5 << endl;
}
