#include <iostream>
using namespace std;

int main () {
	for ( int i = 0; i < 6; i++ ) {
		cout << i << " ";
	}
}
