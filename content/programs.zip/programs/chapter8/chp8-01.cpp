#include <iostream>
using namespace std;

int main () {
	int i = 0;
	while (i < 6) {
		cout << i << " ";
		i++;
	}
}
