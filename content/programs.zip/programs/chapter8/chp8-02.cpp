#include <iostream>
using namespace std;

int main () {
	int i = 0;
	do {
		cout << i << " ";
		i++;
	} while (i < 6);
}
