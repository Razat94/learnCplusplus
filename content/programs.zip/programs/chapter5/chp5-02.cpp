#include <iostream>
#include <string>
using namespace std;
	
int main() {
	int x = 5;
	int y = 3;
	int z = 1;
	
	cout << x + y << endl;
	cout << x - z << endl;
}
