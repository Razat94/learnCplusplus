#include <iostream>
using namespace std;

int main() {
	int x = 5;         // assign the value 5 to x
	int y = 2;         // assign the value 2 to y
	int z = x + y;     // assign the value 7 to z (x + y)
	
	cout << "x: " << x << endl;
	cout << "y: " << y << endl;
	cout << "z: " << z << endl;
	
	string message = "Happy";
	message = message + " " + "Birthday!";
	cout << message;
}
