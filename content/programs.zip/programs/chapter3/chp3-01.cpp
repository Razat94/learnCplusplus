#include <iostream>
using namespace std;

int main {
	int blah;
	blah = 5;
	cout << blah;
	blah = 10;
	cout << blah;
}
