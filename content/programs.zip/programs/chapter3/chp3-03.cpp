#include <iostream> // cout endl cin
using namespace std;

int main(){
    double width; // declaration
    width = 5;

    double height;
    height = 6;
	
    double area;
    area = width * height; // assignment statement
    cout << "area is " <<area <<endl;

    return 0; // fine, unnecessary
} // main
