#include <iostream>
using namespace std;
	
int main() {
	int age;
	cout << "How old are you? ";
	cin >> age;
	cout << "You are " << age << " years old.";
}
