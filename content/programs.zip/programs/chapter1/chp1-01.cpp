// This file is named chp1-01.cpp
#include <iostream>
using namespace std;

int main() {
   cout << "Hello, World!" << endl;
   cout << "My name is Raza!" << " I hope you have a great day!" << endl;
   
   
   
   cout << "Goodbye!";
   return 0;   
}
