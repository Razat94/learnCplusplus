// This file is named chp1-00.cpp

#include <iostream>
using namespace std;

int main() {
   cout << "Hello, World!";
}
