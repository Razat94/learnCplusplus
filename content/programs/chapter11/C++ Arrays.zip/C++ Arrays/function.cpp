#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>  // used for: die function
#include <iterator> // used for: getLength function
using namespace std;

bool die( const string & msg ){
    cout <<"Fatal error: " <<msg <<endl;
    exit( EXIT_FAILURE );
}

// getLength Function. Source: Stack Overflow.
// https://stackoverflow.com/questions/34546262/c-getlength-method-to-get-length-of-an-array#answer-34546666
template <typename T, size_t N>
size_t getLength(T (&arr)[N])
{
  return N;
}

void output ( int arr[], int size ) {
	cout << "{";
	for ( int i = 0; i < size; i++ ) {
		if ( i > 0 ) cout << ", ";
		cout << arr[i];
	}
	cout << "}" <<  endl;
}

void input( int a[], int els ){
    for( int i = 0;  i < els;  i++  ){
        cout <<"[" <<i <<"]: ";
        cin >>a[i] || die( "input failure" );
    }
}

void average( const int a[], unsigned els ){
    double sum = 0;
    for( unsigned i = 0;  i < els;  i++ ){
        sum += a[i];
    }
    cout << "Average: " << sum/els << endl;
}

void arrayIncludes ( int val, int arr[], int size ) {
	for ( int i = 0; i < size; i++ ) {
		if ( arr[i] == val ) {
			cout << val << " was found at index [" << i << "]." <<  endl;
			return;	
		}
	}
	cout << val << " couldn't be found." << endl;
}

void getMax ( int arr[], int size  ) {
	int max = arr[0];
	for ( int i = 1; i < size; i++ ) {
		if ( arr[i] > max ) max = arr[i];
	}
	cout << "Maximum Value: " << max << endl;
}

void getMin ( int arr[], int size  ) {
	int min = arr[0];
	for ( int i = 1; i < size; i++ ) {
		if ( arr[i] < min ) min = arr[i];
	}
	cout << "Minimum Value: " << min << endl;
}

void sort ( int a[] , int size ) {	
	int temp = 0;
	for ( int i = 0 ; i < size ; i++ ) {
		int flag = 0;
		for ( int j = 0 ; j < size-i-1; j++ ) {
			if ( a[j] > a[j+1] ) {
				temp = a[j];
				a[j] = a[j+1];
				a[j+1] = temp;
				flag = 1;
			}
		}
		if ( !flag ) {
			break;
		}
	} // end of loop
}

void findMissingNumber ( int arr[], int size ) {
	if ( arr[0] != 0 ) {
		die ( "size can't be less than 0" );
	}
	for ( int i = 1; i < size; i++ ) {
		if ( i != arr[i] ) {
			cout << "Missing Number: " << i << endl;
			break;
		} 
	}  
}

void isUnique(const int arr[], int size){
	bool isUnique = true;
	
	for (int i = 0; i < size; i++) {
		for (int j = i + 1; j < size; j++) {
			if (arr[i] == arr[j]) isUnique = false;
		}
	}
    
    if (isUnique == true) cout << "The array is unique.";
    else cout << "The array is NOT unique.";
    cout << endl;
}
