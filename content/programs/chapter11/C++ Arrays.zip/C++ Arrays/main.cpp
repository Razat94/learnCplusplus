#include "array-functions.cpp"

int main() {
	mainTestArray();
}
