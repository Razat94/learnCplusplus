#include "function.cpp"

int main() {
	int arr[3] = { 1, 2, 3};
	// input ( arr, 3 );
	output ( arr, 3 );
	average ( arr, 3);
	getMax ( arr, 3 );
	getMin ( arr, 3 );
	
	int a[5] = { 7, 43, 36, 5, 21 };
  	sort ( a , 5 );	
  	output ( a , 5 );
  	
  	int numbers[10] = {0,1,2,3,5,6,7,8,9,10};
	findMissingNumber ( numbers, 10 );
	
	isUnique ( a, 5 );
	arrayIncludes ( 5, a, 5 );
}
