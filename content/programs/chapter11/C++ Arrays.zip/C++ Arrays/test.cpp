#include "function.cpp"

int main() {
	int arr[3] = { 1, 2, 3};
	// input ( arr, 3 );
	output ( arr, getLength(arr) );
	average ( arr, getLength(arr));
	getMax ( arr, getLength(arr) );
	getMin ( arr, getLength(arr) );
	
  	int numbers[10] = {0,1,2,3,5,6,7,8,9,10};
	findMissingNumber ( numbers, getLength(numbers) );
	
	int a[5] = { 7, 43, 36, 5, 21 };
  	sort ( a , 5 );	
  	output ( a , 5 );
  	
  	isUnique ( a, getLength(a) );
	arrayIncludes ( 5, a, getLength(a) );
}
