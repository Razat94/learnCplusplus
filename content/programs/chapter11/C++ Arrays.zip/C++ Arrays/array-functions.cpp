#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>  // used for: die function
#include <iterator> // used for: getLength function
using namespace std;

bool die( const string & msg ){
    cout <<"Fatal error: " <<msg <<endl;
    exit( EXIT_FAILURE );
}

// getLength Function. Source: Stack Overflow.
// https://stackoverflow.com/questions/34546262/c-getlength-method-to-get-length-of-an-array#answer-34546666
template <typename T, size_t N>
size_t getLength(T (&arr)[N]) {
	return N;
}

void input( int a[], int els ){
    for( int i = 0;  i < els;  i++  ){
        cout <<"[" <<i <<"]: ";
        cin >>a[i] || die( "input failure" );
    }
}

void output ( int arr[], int size ) {
	cout << "{";
	for ( int i = 0; i < size; i++ ) {
		if ( i > 0 ) cout << ", ";
		cout << arr[i];
	}
	cout << "}" <<  endl;
}

// Remember, think of 2D arrays like this: X amounts of arrays at Y size. 
// Source: https://www.tutorialspoint.com/Passing-two-dimensional-array-to-a-Cplusplus-function

// In this function, the y size of the array MUST be defined to an int 4.
void twoDArrayOutput ( int a[][4], int xAmounts, int ySize ) {
	cout << "Output of 2D Array: {" << endl;
	for ( int i = 0; i < xAmounts; i++ ) {
		output ( a[i], ySize );
	}
	cout << "}" <<  endl;
} 

void average( const int a[], unsigned els ){
    double sum = 0;
    for( unsigned i = 0;  i < els;  i++ ){
        sum += a[i];
    }
    cout << "Average: " << sum/els << endl;
}

void arrayIncludes ( int val, int arr[], int size ) {
	for ( int i = 0; i < size; i++ ) {
		if ( arr[i] == val ) {
			cout << val << " was found at index [" << i << "]." <<  endl;
			return;	
		}
	}
	cout << val << " couldn't be found." << endl;
}

void getMax ( int arr[], int size  ) {
	int max = arr[0];
	for ( int i = 1; i < size; i++ ) {
		if ( arr[i] > max ) max = arr[i];
	}
	cout << "Maximum Value: " << max << endl;
}

void getMin ( int arr[], int size  ) {
	int min = arr[0];
	for ( int i = 1; i < size; i++ ) {
		if ( arr[i] < min ) min = arr[i];
	}
	cout << "Minimum Value: " << min << endl;
}

void sort ( int a[] , int size ) {	
	int temp = 0;
	for ( int i = 0 ; i < size ; i++ ) {
		int flag = 0;
		for ( int j = 0 ; j < size-i-1; j++ ) {
			if ( a[j] > a[j+1] ) {
				temp = a[j];
				a[j] = a[j+1];
				a[j+1] = temp;
				flag = 1;
			}
		}
		if ( !flag ) {
			break;
		}
	} // end of loop
}

void findMissingNumber ( int arr[], int size ) {
	if ( arr[0] != 0 ) {
		die ( "size can't be less than 0" );
	}
	for ( int i = 1; i < size; i++ ) {
		if ( i != arr[i] ) {
			cout << "Missing Number: " << i << endl;
			break;
		} 
	}  
}

void isUnique(const int arr[], int size){
	bool isUnique = true;
	
	for (int i = 0; i < size; i++) {
		for (int j = i + 1; j < size; j++) {
			if (arr[i] == arr[j]) isUnique = false;
		}
	}
    
    if (isUnique == true) cout << "The array is unique.";
    else cout << "The array is NOT unique.";
    cout << endl;
}

/*

  ==================================
  ====== Array Function Tests ======
  ==================================

*/

void exhaustiveTest( int a[][4], int xAmounts, int ySize ) {
	cout << "=========================" << endl;
	cout << "==== Exhaustive Test ====" << endl;
	cout << "=========================" << endl;
	cout << endl;
	
	for ( int i = 0; i < xAmounts; i++ ) {
		cout << i << "th set: " << endl;
		
		sort    ( a[i], ySize );	
  		output  ( a[i], ySize );
		average ( a[i], ySize );
		getMax  ( a[i], ySize );
		getMin  ( a[i], ySize );
  		isUnique ( a[i], ySize );
		arrayIncludes ( 5, a[i], ySize );
		
		if ( i != xAmounts - 1) cout << endl;
	}
} 

void twoDArrayTest() {
	int twoDArray[5][4] = {{0,1,2,3}, {7,6,5,4}, {10,10,10,11}, { 9999,0,0,1}, {9, 42, 76,9 }};
	twoDArrayOutput ( twoDArray, 5, 4 );
	
	exhaustiveTest( twoDArray, 5, 4 );
}

void mainTestArray() {
	int arr[3] = { 1, 2, 3};
	int numbers[10] = {0,1,2,3,5,6,7,8,9,10};
	int a[5] = { 7, 43, 36, 5, 21 };
	
	// input ( arr, 3 );
	output  ( arr, getLength(arr) );
	average ( arr, getLength(arr));
	getMax  ( arr, getLength(arr) );
	getMin  ( arr, getLength(arr) );
	
	findMissingNumber ( numbers, getLength(numbers) );
	
  	sort ( a , 5 );	
  	output ( a , 5 );
  	isUnique ( a, getLength(a) );
	arrayIncludes ( 5, a, getLength(a) );
	
	twoDArrayTest();
}
